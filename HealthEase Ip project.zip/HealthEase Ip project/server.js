const express= require("express");
const app=express();
const mongoose=require("mongoose");
const bodyParser=require("body-parser");
app.use(express.urlencoded({extended: false}));
app.use(express.static('assets'))
mongoose.connect("mongodb://localhost:27017/", {useNewUrlParser: true},{useUnifiedTopology: true});

//create a data schema
const Schema={
    name:String,
    message:String,
    email:String,
    subject:String
}
const data=mongoose.model("data",Schema);

// const path = require('path')
// app.use('/static', express.static(path.join(__dirname, '/assets')))
// const static_path=path.join(__dirname, "/assets");



app.get("/",function(req,res){
    res.sendFile(__dirname +"/contact.html");
})

app.post("/", function(req,res){
    console.log(req.body);
    let newNote=new data({
        name:req.body.name,
        message:req.body.message,
        email:req.body.email,
        subject:req.body.subject
    });
    newNote.save();
    res.redirect("/index.html");
});

app.listen(3000,function(){
    console.log("server is running at port 3000");
});